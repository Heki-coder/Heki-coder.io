#ifndef telegram_h
#define telegram_h
#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
class Telegram {
    public:
        HTTPClient http;
        Telegram(char* TOKEN, bool Debug);
        void sendMessage(char* message, char* chat_id);
        void WiFi_start(char* SSID, char* Password);
    private:
        char* Token;
        bool debug;
    };
#endif
