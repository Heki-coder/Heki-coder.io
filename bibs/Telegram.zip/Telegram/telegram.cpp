#include "telegram.h"
#include <HTTPClient.h>

Telegram::Telegram(char* TOKEN, bool Debug) {
    Token = TOKEN;
    debug = Debug;
}
void Telegram::WiFi_start(char* SSID, char* Password) {
        WiFi.begin(SSID, Password);
    if (debug) {
        Serial.begin(115200);
    }
        Serial.println("Connecting to WiFi...");
        while (WiFi.status() != WL_CONNECTED) {
            delay(10);
            Serial.print(".");
        }
        Serial.println("Connected");
}
void Telegram::sendMessage(char* message, char* chat_id) {
    String token = String(this->Token);
    HTTPClient http;
    String url = "https://api.telegram.org/bot" + token + "/sendMessage?chat_id=" + String(chat_id) + "&text=" + String(message);
    http.begin(url);
    int response = http.GET();
    if (response > 0 && this->debug) {
        Serial.print("HTTP Response code: ");
        Serial.println(response);
    } else if (this->debug) {
        Serial.print("HTTP Error: ");
        Serial.println(response);
    }
    http.end();
}